

sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/ui/core/Fragment",
    "sap/m/library",
	"sap/ui/thirdparty/jquery"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageBox, Fragment,library,jquery) {
        "use strict";
        var oIllustratedMessageSize = library.IllustratedMessageSize;
        return Controller.extend("uk.co.brakes.automation.createrequi.controller.Main", {
            onInit: function () {
                var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
                var appPath = appId.replaceAll(".", "/");
                this.appModulePath = jQuery.sap.getModulePath(appPath);
            },


            onAfterRendering: function () {
                //this.fetchPlants();
                this.fetchTemplates();
            },
            showBusyDialog: function () {
                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog();
                }
                
                this._oBusyDialog.open();

            },
 
            hideBusyDialog: function () {
                this._oBusyDialog.close();
            },
            showBusyDialog1: function () {

                if (!this._oBusyDialog) {
                    Fragment.load({
                        name: "uk.co.brakes.automation.createrequi.fragments.loader",
                        controller: this
                    }).then(function (oDialog) {
                        this._oBusyDialog = oDialog;
                        this.getView().addDependent(this._oMsgDialog);
                        this._oBusyDialog.open();
                    }.bind(this));
                } else {
                    this._oBusyDialog.open();
                }
            },
 
            hideBusyDialog1: function () {
                this._oBusyDialog.close();
            },

            fetchPlants: function(){
                this.showBusyDialog();
                var that = this;
                $.ajax({
                    url: that.appModulePath+"/sap/opu/odata/BSXC/CREATE_REQ_BPM_SRV/PlantsSet",
                    type: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    //async: false,
                    success: function (oData, response) {
                        that.hideBusyDialog();
                        var cmbTemplates = that.getView().byId("cmbTemplates");
                        var oItemTemplate = new sap.ui.core.ListItem({
                            text: "{TemplateDesc}",
                            key: "{TemplateID}",
                            additionalText: "{TemplateID}"
                        });

                        var noOfTemplates = oData.d.results.length;
                        var json = new sap.ui.model.json.JSONModel(oData.d.results);
                        json.setSizeLimit(noOfTemplates);
                        cmbTemplates.setModel(json);
                        var oBindingInfo = {
                            path: "/",
                            template: oItemTemplate
                        };

                        cmbTemplates.bindAggregation("items", oBindingInfo);
                        //noOfTemplates=0;
                        if (noOfTemplates >= 1) {
                            cmbTemplates.setSelectedKey(cmbTemplates.getItems()[0].getKey());
                        } else if (noOfTemplates == 0) {
                            that.handleMsgs("Error", "MissingData", "Template missing!", "You do not seem to have any templates assigned. Templates are required to create a request.");
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        that.hideBusyDialog();
                        if (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.error && jqXHR.responseJSON.error.message) {
                            that.handleMsgs("Error", "SystemEx", "System Exception", "Please contact system administrator.\n\n" + jqXHR.responseJSON.error.message.value);

                        } else if (jqXHR && jqXHR.responseText) {
                            that.handleMsgs("Error", "SystemEx", "System exception occured!", "Please contact system administrator.\n\n" + jqXHR.responseText);
                        } else {
                            that.handleMsgs("Error", "SystemEx", "System exception occured!", "Please contact system administrator.");
                        }
                    }
                }, this);                
            },

            fetchTemplates: function () {
                this.showBusyDialog();
                var that = this;
                $.ajax({
                    url: that.appModulePath+"/sap/opu/odata/BSXC/CREATE_REQ_BPM_SRV/TemplateSet",
                    type: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    //async: false,
                    success: function (oData, response) {
                        that.hideBusyDialog();
                        var cmbTemplates = that.getView().byId("cmbTemplates");
                        var oItemTemplate = new sap.ui.core.ListItem({
                            text: "{TemplateDesc}",
                            key: "{TemplateID}",
                            additionalText: "{TemplateID}"
                        });

                        var noOfTemplates = oData.d.results.length;
                        var json = new sap.ui.model.json.JSONModel(oData.d.results);
                        json.setSizeLimit(noOfTemplates);
                        cmbTemplates.setModel(json);
                        var oBindingInfo = {
                            path: "/",
                            template: oItemTemplate
                        };

                        cmbTemplates.bindAggregation("items", oBindingInfo);
                        //noOfTemplates=0;
                        if (noOfTemplates >= 1) {
                            cmbTemplates.setSelectedKey(cmbTemplates.getItems()[0].getKey());
                        } else if (noOfTemplates == 0) {
                            that.handleMsgs("Error", "MissingData", "Template missing!", "You do not seem to have any templates assigned. Templates are required to create a request.");
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        that.hideBusyDialog();
                        if (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.error && jqXHR.responseJSON.error.message) {
                            that.handleMsgs("Error", "SystemEx", "System Exception", "Please contact system administrator.\n\n" + jqXHR.responseJSON.error.message.value);

                        } else if (jqXHR && jqXHR.responseText) {
                            that.handleMsgs("Error", "SystemEx", "System exception occured!", "Please contact system administrator.\n\n" + jqXHR.responseText);
                        } else {
                            that.handleMsgs("Error", "SystemEx", "System exception occured!", "Please contact system administrator.");
                        }
                    }
                }, this);
            },
            handleMsgs: function (state, identifier, title, description) {
                var illustratedmsg = "";
                if (identifier === "MissingData") {
                    illustratedmsg = "sapIllus-SimpleEmptyList";
                } else if (identifier === "SystemEx") {
                    illustratedmsg = "sapIllus-Connection";
                } else if (identifier === "Validation") {
                    illustratedmsg = "sapIllus-ErrorScreen";
                } else if (identifier === "Success") {
                    illustratedmsg = "sapIllus-SimpleCheckMark";
                } else if (identifier === "Exception"){
                    illustratedmsg = "sapIllus-UnableToLoad";
                }else{
                    illustratedmsg = "sapIllus-UnableToLoad";
                }

                var msgDialogModel = new sap.ui.model.json.JSONModel({
                    state: state,
                    title: title,
                    description: description,
                    illustratedmsg: illustratedmsg,
                    showNavBtn: state === "Success" ? true : false
                });

                this.getView().setModel(msgDialogModel, "DialogMsgModel");
                // create value help dialog
                if (!this._oMsgDialog) {
                    Fragment.load({
                        name: "uk.co.brakes.automation.createrequi.fragments.message",
                        controller: this
                    }).then(function (oDialog) {
                        this._oMsgDialog = oDialog;
                        this.getView().addDependent(this._oMsgDialog);
                        this._oMsgDialog.setModel(msgDialogModel);
                        this._oMsgDialog.open();
                    }.bind(this));
                } else {
                    this._oMsgDialog.open();
                }
            },
            onMsgDialogClose: function () {
                this._oMsgDialog.close();
            },
            onLiveChange: function (oEvent) {
                var source = oEvent.getSource();
                var sourceId = source.getId();

                // Templates field
                if (sourceId.includes("cmbTemplates")) {
                    var sSelectedKey = source.getSelectedKey(),
                        sValue = source.getValue();

                    if (!sSelectedKey && sValue) {
                        source.setValueState("Error");
                        source.setValueStateText("Please enter a valid template!");
                    } else {
                        source.setValueState("None");
                    }
                }

                // Description field
                if (sourceId.includes("inpDesc")) {
                    var inpDescVal = oEvent.getParameter("value");
                    if (inpDescVal === "" || inpDescVal === null) {
                        source.setValueState("Error");
                        source.setValueStateText("Please enter description for the request!");
                    } else {
                        source.setValueState("None");
                    }
                }
            },
            validateBeforeReqCreation: function () {
                var error = false,
                    templateError = false,
                    descError = false;
                // Template Selected?
                var cmbTemplates = this.getView().byId("cmbTemplates");
                var sSelectedKey = cmbTemplates.getSelectedKey(),
                    sValue = cmbTemplates.getValue();

                if ((sValue === null && sSelectedKey === null) || (sValue === "" && sSelectedKey === "")) {
                    cmbTemplates.setValueState("Error");
                    cmbTemplates.setValueStateText("Please enter a valid template!");
                    templateError = true;
                } else {
                    cmbTemplates.setValueState("None");
                    templateError = false;
                }

                // Description written?
                var inpDesc = this.getView().byId("inpDesc");
                if (inpDesc.getValue() === "" || inpDesc.getValue() === null) {
                    inpDesc.setValueState("Error");
                    inpDesc.setValueStateText("Please enter description for the request!");
                    descError = true;
                } else {
                    inpDesc.setValueState("None");
                    descError = false;
                }

                if (templateError || descError) {
                    error = true;
                } else {
                    error = false;
                }
                return error;

            },
            getCSRFToken: function(url) {
                var token = null;
                $.ajax({
                    url: url,
                    type: "GET",
                    async: false,
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader("X-CSRF-Token", "Fetch");
                    },
                    complete: function(xhr) {
                        token = xhr.getResponseHeader("X-CSRF-Token");
                    }
                });
                return token;
            },

            createRequest: function () {
                this.showBusyDialog();
                var error = this.validateBeforeReqCreation();
                if (error) {
                    this.hideBusyDialog();
                    this.handleMsgs("Error", "Validation", "Validation failed!", "There seems to be some issue with the data you have provided. Please check the highligted field(s) in the form.");
                } else {

                    var payload = {
                        TemplateID: this.getView().byId("cmbTemplates").getSelectedKey(),
                        CrDesc: this.getView().byId("inpDesc").getValue(),
                        CrNo: "",
                        Type: "",
                        Message: ""
                    };
                    var that = this;
                    var url = that.appModulePath+"/sap/opu/odata/BSXC/CREATE_REQ_BPM_SRV/RequestDataSet";
                    $.ajax({
                        url: url,
                        type: "POST",
                        contentType: "application/json",
                        dataType: "json",
                        data: JSON.stringify(payload),
                        beforeSend: function(xhr) {
                            var param = url;
                            var token = that.getCSRFToken(param);
                            xhr.setRequestHeader("X-CSRF-Token", token);
                            xhr.setRequestHeader("Accept", "application/json");
            
            
                        },
                        success: function (oData, response) {
                            that.hideBusyDialog();
                            //S,E,W,I
                            var msgType = oData.d.Type,
                                msg = oData.d.Message;                             
                            if(msgType === "S"){
                                msg = msg ? "A new request with request number "+ oData.d.CrNo +" has been created successfully." : "A new request has been created successfully.";
                                that.handleMsgs("Success", "Success", "Request created successfully!", msg);
                                that.getView().byId("inpDesc").setValue("");
                            }else if(msgType === "W"){
                                msg = msg ? msg : "Please contact system administrator.";
                                that.handleMsgs("Warning", "Warning", "Warning!", msg);
                            }else if(msgType === "E"){
                                msg = msg ? msg : "Please contact system administrator.";
                                that.handleMsgs("Error", "Exception", "Error!", msg);
                            }else{
                                that.handleMsgs("Error", "SystemEx", "System exception occured!", "Please contact system administrator.");
                            }
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            that.hideBusyDialog();
                            if (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.error && jqXHR.responseJSON.error.message) {
                                that.handleMsgs("Error", "SystemEx", "System exception occured!", "Please contact system administrator.\n\n" + jqXHR.responseJSON.error.message.value);

                            } else if (jqXHR && jqXHR.responseText) {
                                that.handleMsgs("Error", "SystemEx", "System exception occured!", "Please contact system administrator.\n\n" + jqXHR.responseText);
                            } else {
                                that.handleMsgs("Error", "SystemEx", "System exception occured!", "Please contact system administrator.");
                            }

                        }
                    }, this);
                }

            },
            createRequestDummy: function () {
                var that = this;
                setTimeout(function () {
                    MessageBox.success("Request 12345 created successfully. \n\n Navigating to the automation dashboard...", {
                        actions: ["Ok"],
                        onClose: function () {
                            if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {

                                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

                                oCrossAppNavigator.toExternal({
                                    target: { semanticObject: "Process_Dashboard", action: "Display" }, //the app you're navigating to

                                });

                            } else { var text = "Cannot Navigate - Application Running Standalone"; jQuery.sap.log.info(text); othis.error(text); }
                        }
                    });
                }, 500);
            },
            navToProcessingDashboard: function () {

                if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {

                    var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

                    oCrossAppNavigator.toExternal({
                        target: { semanticObject: "Processing_Dashboard", action: "Display" }, //the app you're navigating to

                    });

                } else { var text = "Cannot Navigate - Application Running Standalone"; jQuery.sap.log.info(text); othis.error(text); }
                //Process_Dashboard-Display
                // var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
                //var hrefForProductDisplay = oCrossAppNav.hrefForExternal({
                //   target: { semanticObject: "Process_Dashboard", action: "Display" }
                //});
            }
        });
    });
