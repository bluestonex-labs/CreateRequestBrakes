sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("uk.co.brakes.automation.createrequi.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  